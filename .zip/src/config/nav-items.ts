export const navItems = [
  {
    label: 'Home',
    path: '/',
  },
  {
    label: 'Blogs',
    path: '/blogs',
  },
  {
    label: 'Contact',
    path: '/projects',
  },
  {
    label: 'Support',
    path: '/contact',
  },
]