(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/src_7f78bdf5._.js",
  "static/chunks/043e8_next_b5312e8f._.js",
  "static/chunks/b2692_react-icons_fa6_index_mjs_994e0627._.js",
  "static/chunks/b2692_react-icons_lib_d4addfaa._.js",
  "static/chunks/9c939_tailwind-merge_dist_bundle-mjs_mjs_5274cb0a._.js",
  "static/chunks/d42b0_motion_dist_es_73cf79ed._.js",
  "static/chunks/node_modules__pnpm_2c802dd3._.js"
],
    source: "dynamic"
});
