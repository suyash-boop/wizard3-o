(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d2d89e51._.js",
  "static/chunks/043e8_next_dist_compiled_5b2ceda0._.js",
  "static/chunks/043e8_next_dist_client_6728f717._.js",
  "static/chunks/043e8_next_dist_4358df48._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
