globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/043e8_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d2d89e51._.js",
    "static/chunks/043e8_next_dist_compiled_5b2ceda0._.js",
    "static/chunks/043e8_next_dist_client_6728f717._.js",
    "static/chunks/043e8_next_dist_4358df48._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js",
    "static/chunks/_e69f0d32._.js",
    "static/chunks/_e10bd688._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];